<?php
/**
 * DouPHP
 * --------------------------------------------------------------------------------------------------
 * 版权所有 2013-2018 漳州豆壳网络科技有限公司，并保留所有权利。
 * 网站地址: http://www.douco.com
 * --------------------------------------------------------------------------------------------------
 * 这不是一个自由软件！您只能在遵守授权协议前提下对程序代码进行修改和使用；不允许对程序代码以任何形式任何目的的再发布。
 * 授权协议：http://www.douco.com/license.html
 * --------------------------------------------------------------------------------------------------
 * Author: DouCo
 * Release Date: 2018-05-23
 */

// 插件
$_LANG['plugin'] = '插件扩展';
$_LANG['plugin_enable'] = '启用插件';
$_LANG['plugin_edit'] = '编辑插件';
$_LANG['plugin_name'] = '插件名称';
$_LANG['plugin_description'] = '插件描述';
$_LANG['plugin_ver'] = '插件版本';
$_LANG['plugin_enable_btn'] = '启用';
$_LANG['plugin_setting'] = '配置';
$_LANG['plugin_disable'] = '停用';
$_LANG['plugin_list'] = '管理插件';
$_LANG['plugin_install'] = '获取更多插件';
$_LANG['plugin_del'] = '删除插件';

// 操作提示
$_LANG['plugin_enable_succes'] = '启用插件成功';
$_LANG['plugin_edit_succes'] = '编辑插件成功';
$_LANG['plugin_disable_succes'] = '成功停用插件';
?>